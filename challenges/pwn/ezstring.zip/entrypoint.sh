#!/bin/sh
set -eu

# Keep local behavior aligned with remote CTF conventions.
printf '%s\n' "${A1CTF_FLAG}" > /flag
chmod 444 /flag

exec socat "TCP-LISTEN:1337,reuseaddr,fork" "EXEC:/ctf/warmup,stderr"
