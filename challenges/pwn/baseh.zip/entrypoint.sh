#!/bin/sh
set -eu

# If A1CTF_FLAG is provided, write it to /flag, unset it, then exec CMD.
if [ -n "${A1CTF_FLAG-}" ]; then
    # write raw A1CTF_FLAG to /flag
    echo "${A1CTF_FLAG}" > /flag || true
    chmod 444 /flag || true
    # remove the environment variable so it's not visible to the service
    unset A1CTF_FLAG
fi

# Exec the command provided as CMD (e.g., socat TCP-LISTEN:1337,reuseaddr,fork EXEC:/ctf/pwn,stderr)
exec "$@"
