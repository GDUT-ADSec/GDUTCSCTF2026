#!/bin/sh
set -eu

if [ -n "${A1CTF_FLAG-}" ]; then
	printf '%s\n' "$A1CTF_FLAG" > /flag || true
	chmod 444 /flag || true
	unset A1CTF_FLAG
fi

exec "$@"
